import { createApp } from 'vue'
import { createPinia } from 'pinia'
import router from './router/index.ts'
import App from './App.vue'
import './index.css'

const pinia = createPinia()

const app = createApp(App)

app.use(pinia)
app.use(router)
app.mount('#root')