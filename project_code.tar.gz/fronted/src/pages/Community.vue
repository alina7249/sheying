<template>
  <div class="min-h-screen bg-[#1E2532]">
    <div class="max-w-7xl mx-auto px-4 py-8">
      <!-- 页面头部 -->
      <div class="page-header fade-in-up">
        <div class="header-content">
          <div>
            <h1 class="text-3xl font-bold text-white">摄影社区</h1>
            <p class="text-[#B8C6D8] mt-2">与全球摄影爱好者交流分享，一起探索摄影的无限可能</p>
          </div>
          <div class="header-actions">
            <Button @click="handleCreatePost" ariaLabel="发布新帖子">
              <i class="fa-solid fa-plus mr-2"></i>
              <span>发布帖子</span>
            </Button>
          </div>
        </div>
      </div>

      <!-- 统计数据卡片 -->
      <div class="stats-grid fade-in-up" style="animation-delay: 0.1s;">
        <div class="stat-card">
          <div class="stat-icon blue">
            <i class="fa-solid fa-users"></i>
          </div>
          <div>
            <p class="stat-value" style="font-variant-numeric: tabular-nums">12,456</p>
            <p class="stat-label">社区成员</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon green">
            <i class="fa-solid fa-images"></i>
          </div>
          <div>
            <p class="stat-value" style="font-variant-numeric: tabular-nums">89,234</p>
            <p class="stat-label">摄影作品</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon purple">
            <i class="fa-solid fa-comments"></i>
          </div>
          <div>
            <p class="stat-value" style="font-variant-numeric: tabular-nums">234,567</p>
            <p class="stat-label">讨论回复</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon orange">
            <i class="fa-solid fa-fire"></i>
          </div>
          <div>
            <p class="stat-value" style="font-variant-numeric: tabular-nums">1,234</p>
            <p class="stat-label">今日活跃</p>
          </div>
        </div>
      </div>

      <!-- 主要内容区 -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
        <!-- 左侧主内容 -->
        <div class="lg:col-span-2 space-y-6">
          <!-- 帖子列表 -->
          <div v-if="loading" class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div v-for="n in 4" :key="n" class="bg-[#1E2532] rounded-2xl h-80 animate-pulse"></div>
          </div>

          <div v-else-if="posts.length === 0" class="text-center py-20 bg-[#1E2532] rounded-2xl border border-[#4A5F8B]/20">
            <i class="fa-regular fa-image text-5xl text-[#6B7C93] mb-4"></i>
            <p class="text-[#B8C6D8] text-lg">暂无作品</p>
          </div>

          <div v-else class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div
              v-for="(post, index) in posts"
              :key="post.id"
              class="fade-in-up"
              :style="{ animationDelay: `${0.3 + index * 0.1}s` }"
            >
              <PhotographyCard :post="post" @update="handlePostUpdate" />
            </div>
          </div>

          <!-- 加载更多 -->
          <div v-if="posts.length < total" class="load-more fade-in-up text-center mt-8" style="animation-delay: 0.8s;">
            <Button variant="outline" @click="handleLoadMore" :disabled="loadingMore">
              <i v-if="loadingMore" class="fa-solid fa-circle-notch fa-spin mr-2"></i>
              <i v-else class="fa-solid fa-plus mr-2"></i>
              {{ loadingMore ? '加载中…' : '加载更多' }}
            </Button>
          </div>
        </div>

        <!-- 右侧边栏 -->
        <div class="space-y-6">
          <!-- 搜索框 -->
          <div class="sidebar-section fade-in-up" style="animation-delay: 0.2s;">
            <form @submit.prevent="handleSearch" class="search-box">
              <i class="fa-solid fa-search search-icon"></i>
              <input
                type="text"
                v-model="searchQuery"
                placeholder="搜索作品、摄影师或标签…"
                class="search-input"
              />
            </form>
          </div>

          <!-- 热门话题 -->
          <div class="sidebar-section fade-in-up" style="animation-delay: 0.3s;">
            <h3 class="section-title">
              <i class="fa-solid fa-fire mr-2"></i>
              热门话题
            </h3>
            <div class="topics-list">
              <div
                v-for="(topic, idx) in trendingTopics"
                :key="topic.id"
                class="topic-item"
                :class="idx === 0 ? 'topic-item-top' : ''"
                @click="handleTopicClick(topic)"
              >
                <span class="topic-rank" :class="idx < 3 ? 'topic-rank-hot' : ''">{{ idx + 1 }}</span>
                <span class="topic-emoji">{{ topic.emoji }}</span>
                <div class="topic-info">
                  <p class="topic-name">{{ topic.name }}</p>
                  <p class="topic-discussions">{{ topic.discussions.toLocaleString() }} 讨论</p>
                </div>
                <i class="fa-solid fa-chevron-right text-[#6B7C93]"></i>
              </div>
            </div>
            <button class="view-all-btn" @click="showInfo('查看全部话题')">
              查看全部话题 <i class="fa-solid fa-arrow-right ml-2"></i>
            </button>
          </div>

          <!-- 活跃用户 -->
          <div class="sidebar-section fade-in-up" style="animation-delay: 0.4s;">
            <h3 class="section-title">
              <i class="fa-solid fa-star mr-2"></i>
              活跃用户
            </h3>
            <div class="users-list">
              <UserCard
                v-for="user in activeUsers"
                :key="user.id"
                :user="user"
                @follow="handleFollowUser"
              />
            </div>
            <button class="view-all-btn" @click="showInfo('发现更多用户')">
              发现更多 <i class="fa-solid fa-arrow-right ml-2"></i>
            </button>
          </div>

          <!-- 摄影挑战 -->
          <div class="challenge-card fade-in-up" style="animation-delay: 0.5s;">
            <div class="challenge-header">
              <div class="challenge-icon">
                <i class="fa-solid fa-trophy"></i>
              </div>
              <span class="challenge-badge">进行中</span>
            </div>
            <h3 class="challenge-title">加入摄影挑战</h3>
            <p class="challenge-desc">本周主题：「城市微光」- 用镜头捕捉都市的迷人夜景</p>
            <div class="challenge-stats">
              <div class="challenge-stat">
                <span class="stat-number">892</span>
                <span class="stat-text">参与作品</span>
              </div>
              <div class="challenge-divider"></div>
              <div class="challenge-stat">
                <span class="stat-number">5</span>
                <span class="stat-text">天剩余</span>
              </div>
            </div>
            <Button variant="primary" class="challenge-btn" @click="handleJoinChallenge">
              立即参与
            </Button>
          </div>

          <!-- 社区公告 -->
          <div class="sidebar-section announcement fade-in-up" style="animation-delay: 0.6s;">
            <h3 class="section-title">
              <i class="fa-solid fa-bullhorn mr-2"></i>
              社区公告
            </h3>
            <div class="announcement-list">
              <div class="announcement-item">
                <div class="announcement-date">11月15日</div>
                <p class="announcement-text">📢 新版社区功能上线，快来体验吧！</p>
              </div>
              <div class="announcement-item">
                <div class="announcement-date">11月10日</div>
                <p class="announcement-text">🎨 「黑白影像」专题摄影展开始征集</p>
              </div>
              <div class="announcement-item">
                <div class="announcement-date">11月5日</div>
                <p class="announcement-text">🏆 10月优秀摄影师名单公布</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import { toast } from 'vue-sonner';
import Button from '../components/common/Button.vue';
import PhotographyCard, { type PostVO } from '../components/PhotographyCard.vue';
import { getPostList } from '../services/api';
import { useAuthStore } from '../store/authStore';

const router = useRouter();
const authStore = useAuthStore();

const searchQuery = ref('');
const posts = ref<PostVO[]>([]);
const loading = ref(true);
const loadingMore = ref(false);
const currentPage = ref(1);
const pageSize = 10;
const total = ref(0);

const loadPosts = async (page: number = 1, append: boolean = false) => {
  if (append) {
    loadingMore.value = true;
  } else {
    loading.value = true;
  }

  try {
    const res: any = await getPostList({
      current: page,
      pageSize: pageSize,
    });

    if (res && res.data) {
      const records = res.data.records || [];
      if (append) {
        posts.value = [...posts.value, ...records];
      } else {
        posts.value = records;
      }
      total.value = res.data.total || 0;
      currentPage.value = page;
    }
  } catch (error: any) {
    console.error('Failed to load posts:', error);
    toast.error(error.message || '加载失败');
  } finally {
    loading.value = false;
    loadingMore.value = false;
  }
};

const handleLoadMore = () => {
  if (loadingMore.value || posts.value.length >= total.value) return;
  loadPosts(currentPage.value + 1, true);
};

const handleSearch = () => {
  if (!searchQuery.value.trim()) return;
  router.push(`/search-result?q=${encodeURIComponent(searchQuery.value.trim())}`);
};

const handleCreatePost = () => {
  if (!authStore.isAuthenticated) {
    toast.warning('请先登录');
    router.push('/login');
    return;
  }
  router.push('/publish');
};

const handlePostUpdate = (updatedPost: PostVO) => {
  const index = posts.value.findIndex(p => p.id === updatedPost.id);
  if (index !== -1) {
    posts.value[index] = updatedPost;
  }
};

const trendingTopics = [
  { id: '1', name: '#城市街头摄影', discussions: 2341, emoji: '🌆' },
  { id: '2', name: '#人像摄影技巧', discussions: 1856, emoji: '📸' },
  { id: '3', name: '#风光摄影', discussions: 1478, emoji: '🏞️' },
  { id: '4', name: '#器材评测', discussions: 987, emoji: '📷' },
  { id: '5', name: '#后期修图', discussions: 765, emoji: '🎨' },
  { id: '6', name: '#胶片摄影', discussions: 543, emoji: '🎞️' }
];

const handleTopicClick = (topic: { id: string; name: string }) => {
  const keyword = topic.name.replace('#', '');
  router.push(`/search-result?q=${encodeURIComponent(keyword)}`);
};

const activeUsers = [
  { id: 1, name: '光影猎人', avatar: 'https://picsum.photos/400/400?random=10', level: 8, followers: 1256 },
  { id: 2, name: '城市漫步者', avatar: 'https://picsum.photos/400/400?random=11', level: 6, followers: 892 },
  { id: 3, name: '夜空守望者', avatar: 'https://picsum.photos/400/400?random=12', level: 7, followers: 1034 },
  { id: 4, name: '胶片情怀', avatar: 'https://picsum.photos/400/400?random=13', level: 5, followers: 678 },
];

const showInfo = (msg: string) => {
  toast.info(msg);
};

const handleFollowUser = (_userId: number) => {
  toast.info('关注功能开发中');
};

const handleJoinChallenge = () => {
  toast.info('摄影挑战功能开发中');
};

onMounted(() => {
  loadPosts(1, false);
});
</script>

<style scoped>
.fade-in-up {
  opacity: 0;
  animation: fadeInUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.page-header {
  background: linear-gradient(135deg, rgba(74, 95, 139, 0.15) 0%, rgba(138, 80, 255, 0.1) 100%);
  border: 1px solid rgba(74, 95, 139, 0.3);
  border-radius: 20px;
  padding: 32px;
  margin-bottom: 24px;
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  flex-wrap: wrap;
  gap: 16px;
}

.header-actions {
  display: flex;
  gap: 12px;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
}

.stat-card {
  background: linear-gradient(135deg, rgba(45, 55, 72, 0.6), rgba(45, 55, 72, 0.3));
  border: 1px solid rgba(74, 95, 139, 0.15);
  border-radius: 16px;
  padding: 20px;
  display: flex;
  align-items: center;
  gap: 16px;
  transition: border-color 0.3s ease;
}

.stat-card:hover {
  border-color: rgba(74, 95, 139, 0.4);
}

.stat-icon {
  width: 52px;
  height: 52px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 22px;
  color: #F5F7FA;
}

.stat-icon.blue {
  background: linear-gradient(135deg, #4A5F8B, #3A4B6F);
}

.stat-icon.green {
  background: linear-gradient(135deg, #48BB78, #38A169);
}

.stat-icon.purple {
  background: linear-gradient(135deg, #8a50ff, #6b3fd4);
}

.stat-icon.orange {
  background: linear-gradient(135deg, #F6AD55, #DD6B20);
}

.stat-value {
  font-size: 24px;
  font-weight: 700;
  color: #F5F7FA;
  margin: 0 0 4px 0;
}

.stat-label {
  font-size: 13px;
  color: #B8C6D8;
  margin: 0;
}

.filter-section {
  background: #2D3748;
  border: 1px solid #4A5F8B;
  border-radius: 16px;
  padding: 20px;
}

.filter-header {
  margin-bottom: 16px;
}

.filter-buttons {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}

.filter-btn {
  padding: 10px 18px;
  background: #1E2532;
  color: #B8C6D8;
  border: 1px solid rgba(74, 95, 139, 0.3);
  border-radius: 10px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
}

.filter-btn:hover {
  color: #F5F7FA;
  background: rgba(74, 95, 139, 0.2);
  border-color: #4A5F8B;
}

.filter-btn.active {
  background: #4A5F8B;
  color: #F5F7FA;
  border-color: #4A5F8B;
  box-shadow: 0 4px 12px -4px rgba(74, 95, 139, 0.4);
}

.posts-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.load-more {
  text-align: center;
  padding: 20px;
}

.sidebar-section {
  background: #2D3748;
  border: 1px solid #4A5F8B;
  border-radius: 16px;
  padding: 24px;
}

.search-box {
  position: relative;
}

.search-icon {
  position: absolute;
  left: 16px;
  top: 50%;
  transform: translateY(-50%);
  color: #B8C6D8;
  font-size: 16px;
}

.search-input {
  width: 100%;
  padding: 14px 16px 14px 48px;
  background: #1E2532;
  border: 1px solid #4A5F8B;
  color: #F5F7FA;
  border-radius: 12px;
  font-size: 14px;
  transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

.search-input:focus {
  outline: 2px solid #6B7C93;
  outline-offset: 2px;
  border-color: #6B7C93;
  box-shadow: 0 0 0 3px rgba(74, 95, 139, 0.2);
}

.search-input::placeholder {
  color: #B8C6D8;
}

.section-title {
  font-size: 16px;
  font-weight: 700;
  color: #F5F7FA;
  margin: 0 0 20px 0;
  display: flex;
  align-items: center;
}

.section-title i {
  color: #4A5F8B;
}

.topics-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-bottom: 16px;
}

.topic-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  background: #1E2532;
  border-radius: 12px;
  transition: all 0.3s ease;
  cursor: pointer;
}

.topic-item:hover {
  background: rgba(74, 95, 139, 0.2);
  transform: translateX(4px);
}

.topic-emoji {
  font-size: 24px;
}

.topic-rank {
  font-size: 14px;
  font-weight: 700;
  color: #6B7C93;
  width: 22px;
  text-align: center;
  flex-shrink: 0;
  font-variant-numeric: tabular-nums;
}

.topic-rank-hot {
  color: #F6AD55;
}

.topic-item-top {
  background: linear-gradient(135deg, rgba(246, 173, 85, 0.08), rgba(74, 95, 139, 0.08));
  border: 1px solid rgba(246, 173, 85, 0.15);
}

.topic-info {
  flex: 1;
  min-width: 0;
}

.topic-name {
  font-size: 14px;
  font-weight: 600;
  color: #F5F7FA;
  margin: 0 0 2px 0;
}

.topic-discussions {
  font-size: 12px;
  color: #B8C6D8;
  margin: 0;
}

.view-all-btn {
  width: 100%;
  padding: 10px 16px;
  background: transparent;
  border: 1px solid rgba(74, 95, 139, 0.3);
  color: #4A5F8B;
  border-radius: 10px;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
}

.view-all-btn:hover {
  background: rgba(74, 95, 139, 0.1);
  border-color: #4A5F8B;
}

.users-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-bottom: 16px;
}

.challenge-card {
  background: linear-gradient(135deg, rgba(72, 187, 120, 0.15) 0%, rgba(74, 95, 139, 0.15) 100%);
  border: 1px solid rgba(72, 187, 120, 0.3);
  border-radius: 16px;
  padding: 24px;
}

.challenge-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.challenge-icon {
  width: 48px;
  height: 48px;
  border-radius: 14px;
  background: linear-gradient(135deg, #48BB78, #38A169);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 22px;
  color: #F5F7FA;
}

.challenge-badge {
  padding: 4px 12px;
  background: rgba(72, 187, 120, 0.2);
  color: #48BB78;
  font-size: 11px;
  font-weight: 600;
  border-radius: 20px;
}

.challenge-title {
  font-size: 18px;
  font-weight: 700;
  color: #F5F7FA;
  margin: 0 0 8px 0;
}

.challenge-desc {
  font-size: 13px;
  color: #B8C6D8;
  line-height: 1.6;
  margin: 0 0 20px 0;
}

.challenge-stats {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 20px;
}

.challenge-stat {
  display: flex;
  flex-direction: column;
  flex: 1;
}

.stat-number {
  font-size: 20px;
  font-weight: 700;
  color: #48BB78;
  margin-bottom: 2px;
  font-variant-numeric: tabular-nums;
}

.stat-text {
  font-size: 12px;
  color: #B8C6D8;
}

.challenge-divider {
  width: 1px;
  height: 32px;
  background: rgba(74, 95, 139, 0.3);
}

.challenge-btn {
  width: 100%;
  background: linear-gradient(135deg, #48BB78, #38A169);
  border: none;
}

.challenge-btn:hover {
  background: linear-gradient(135deg, #38A169, #2F855A);
}

.announcement {
  border-color: rgba(246, 173, 85, 0.3);
}

.announcement-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.announcement-item {
  padding: 12px;
  background: #1E2532;
  border-radius: 10px;
}

.announcement-date {
  font-size: 11px;
  color: #F6AD55;
  font-weight: 500;
  margin-bottom: 4px;
}

.announcement-text {
  font-size: 13px;
  color: #B8C6D8;
  margin: 0;
  line-height: 1.5;
}

@media (prefers-reduced-motion: reduce) {
  .fade-in-up {
    animation: none;
    opacity: 1;
  }

  .stat-card,
  .topic-item,
  .filter-btn {
    transition: none;
  }
}
</style>
