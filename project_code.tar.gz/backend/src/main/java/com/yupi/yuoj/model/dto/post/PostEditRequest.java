package com.yupi.yuoj.model.dto.post;

import java.io.Serializable;
import java.util.List;
import lombok.Data;

/**
 * 编辑请求
 *
 * @author <a href="https://github.com/liyupi">程序员鱼皮</a>
 * @from <a href="https://yupi.icu">编程导航知识星球</a>
 */
@Data
public class PostEditRequest implements Serializable {

    /**
     * id
     */
    private Long id;

    /**
     * 标题
     */
    private String title;

    /**
     * 内容
     */
    private String content;

    /**
     * 标签列表
     */
    private List<String> tags;

    /**
     * 作品图片
     */
    private String imageUrl;

    /**
     * 相机
     */
    private String camera;

    /**
     * 镜头
     */
    private String lens;

    /**
     * 光圈
     */
    private String aperture;

    /**
     * 快门
     */
    private String shutter;

    /**
     * ISO
     */
    private String iso;

    private static final long serialVersionUID = 1L;
}